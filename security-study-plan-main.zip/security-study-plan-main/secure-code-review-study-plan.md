# Theory
- [OWASP Code Review Guide](https://owasp.org/www-project-code-review-guide/)

# Practice:
- [OWASP Secure Coding Dojo](https://owasp.org/www-project-secure-coding-dojo/)
